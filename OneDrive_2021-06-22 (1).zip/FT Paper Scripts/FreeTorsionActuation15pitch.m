% clear all
clc
close all


% % Retrieve Free Torsion Dec 10 Test 1 
%     filename = 'ActuationRheom_T0_PA15_Dec10-18_1.xls';
%     sheet = 'Axial - 1';
%      reh_data1_Dec10 = xlsread(filename, sheet,'A:G');
%        timereh1_Dec10 = reh_data1_Dec10(1:end,1);
%        Disp1_Dec10 = reh_data1_Dec10(1:end,2);
%        Gap1_Dec10 = reh_data1_Dec10(1:end,3);
%        Torque1_Dec10 = reh_data1_Dec10(1:end,4);
%        AxialForce1_Dec10 = reh_data1_Dec10(1:end,5);
%        Interp_Temp1_Dec10 = reh_data1_Dec10(1:end,6); 
%        
%        
% % Retrieve Free Torsion Dec 10 Test 2 
%     filename = 'ActuationRheom_T0_PA15_Dec10-18_2.xls';
%     sheet = 'Axial - 1';
%      reh_data2_Dec10 = xlsread(filename, sheet,'A:G');
%        timereh2_Dec10 = reh_data2_Dec10(1:end,1);
%        Disp2_Dec10 = reh_data2_Dec10(1:end,2);
%        Gap2_Dec10 = reh_data2_Dec10(1:end,3);
%        Torque2_Dec10 = reh_data2_Dec10(1:end,4);
%        AxialForce2_Dec10 = reh_data2_Dec10(1:end,5);      
%        Interp_Temp2_Dec10 = reh_data2_Dec10(1:end,6); 
       
% Retrieve Charlie Data 
temp = [25:5:100];
STRAIN = csvread('FT_15PA_5mm_e11update_STRAIN.csv');
%STRAIN = csvread('FT_15PA_5mm_mid_STRAIN.csv');
twist = STRAIN(:,1);
axial = STRAIN(:,2)*100;
%Conversion to degrees and torque to N/mm
L0 = 17.5; %mm
D = 0.89; %mm
R = D/2; %mm


%ANALYTICAL FREE TORSION 

% Thermal strains:

T = (23:1:110);
T0 = 23;

TE22 = 10^(-6)*(1.1*(T.^2 - T0.^2) + 48.2*(T - T0)); % new newest
%TE11 = 10^(-6)*(-0.0091*T.^3 + 0.9536*T.^2 - 32.05*T - (-0.0091*T0.^3 + 0.9536*T0.^2 - 32.05*T0)); % Newest
TE11 = (-1.905939104908804e-08*(T.^3-T0.^3) + 2.330006828099087e-06*(T.^2-T0.^2) -9.278398709519304e-05*(T-T0));
%TE11 = -2.811993987928945e-08*(T.^3-T0.^3) + 3.345051826452319e-06*(T.^2-T0.^2) -1.337544800607228e-04*(T-T0); % Least Squares Regression Method
%TE11 = 10^(-6)*(-0.006497*(T.^3 - T0.^3) - 0.241*(T.^2 -T0.^2) - 53.5*(T - T0)); % October 2018
%TE11 = -9.951e-09*(T.^3 - T0.^3)+2.113e-07*(T.^2 -T0.^2)+ 3.159e-05*(T - T0); % May 2019
%TE11_Amy = 10^(-6)*(-0.009357*(T.^3 - T0.^3) + 0.1005*(T.^2 -T0.^2) - 38.17*(T - T0)); % May 2019 AMY
%TE11_AmyCheck = 10^(-6)*(-0.009357*(T.^3 - T0.^3) + 0.1005*(T.^2 -T0.^2) + 38.17*(T - T0)); 

Phi0 = 2*L0/(D*tand(75));

r1 = 1*R; %Radial position
r0_5 = 0.5*R;
r0_01 = 0.01*R;

x1 = r1*Phi0/L0;
x0_5 = r0_5*Phi0/L0;
x0_01 = r0_01*Phi0/L0;

dPhi1 = 2*x1*(TE11 - TE22)/(x1^2+1); % delta phi, SMASIS
dPhi0_01 = 2*x0_01*(TE11 - TE22)/(x0_01^2+1); % delta phi, SMASIS
dL1 = L0*(TE22*x1^2 + TE11)/(x1^2+1)/L0*100; % delta L, SMASIS
dL0_01 = L0*(TE22*x0_01^2 + TE11)/(x0_01^2+1)/L0*100; % delta L, SMASIS. This term is equal to
%the axial thermal contraction when the pitch angle is equal to 0 degrees.


%dPhi_avg = 2*L0^2/(Phi0*R^2)*(TE11-TE22)*log((Phi0*R/L0)^2 + 1)*R/L0;
dL_avg = L0^3/(Phi0^2*R^2)*((TE11-TE22)*log(1+(Phi0*R/L0)^2) + TE22*(Phi0*R/L0)^2)/L0*100;
dPhi_avg = (4*L0*(TE11-TE22)/(R^2*Phi0^2))*(Phi0*R - (L0*atan(Phi0*R/L0)));

set(groot, 'DefaultTextInterpreter', 'LaTeX', ...
           'DefaultAxesTickLabelInterpreter', 'LaTeX', ...
           'DefaultAxesFontName', 'LaTeX', ...
           'DefaultLegendInterpreter', 'LaTeX', ...
           'defaultFigureColor','w');

fig1=figure; hold on; grid on; set(gca,'FontSize',20);



 % Retrieve Free torsion PA 75 6-11-2019 Test 1
  filename = 'Free torsion 75PA Test 1 6-11-19';
    sheet = 'Sheet1';
     FreeTorsion_6_11 = xlsread(filename, sheet,'A:B');
       thetatemp_freeTorsion__6_11 = FreeTorsion_6_11(1:end,1);
       dPhi1_6_11 = FreeTorsion_6_11(1:end,2);
 

%  % thermal axial contraction PA 75 5-23-2019
%     filename = 'thermalaxialcontractiondata75PA';
%     sheet = 'Sheet1';
%      newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
%        thetatemp = newaxialthermalcontraction(1:end,1);
%        Epsilon_new = newaxialthermalcontraction(1:end,2);
%  
%  % thermal axial contraction PA 75 6-3-2019
%     filename = 'thermalaxialcontractiondata75PA 6-3-19';
%     sheet = 'Sheet1';
%      newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
%        thetatemp2 = newaxialthermalcontraction(1:end,1);
%        Epsilon_new2 = newaxialthermalcontraction(1:end,2);
%        
%  % thermal axial contraction PA 75 6-4-2019
%     filename = 'thermalaxialcontractiondata75PA 6-4-19';
%     sheet = 'Sheet1';
%      newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
%        thetatemp3 = newaxialthermalcontraction(1:end,1);
%        Epsilon_new3 = newaxialthermalcontraction(1:end,2);       
       
% thermal axial contraction PA 75 6-10-2019 Test 2
  filename = 'thermalaxialcontractiondata75PA Test 2 6-11-19';
    sheet = 'Sheet1';
     newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
       thetatemp4 = newaxialthermalcontraction(1:end,1);
       Epsilon_new4 = newaxialthermalcontraction(1:end,2);

% thermal axial contraction PA 75 6-11-2019 Test 3
  filename = 'thermalaxialcontractiondata75PA Test 3 6-11-19';
    sheet = 'Sheet1';
     newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
       thetatemp5 = newaxialthermalcontraction(1:end,1);
       Epsilon_new5 = newaxialthermalcontraction(1:end,2);
       
% Free Torsion PA 75 6-13-2019 Test 1
  filename = 'Free torsion 75PA Test 1 6-13-19';
    sheet = 'Sheet1';
     newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
       thetatemp_freeTorsion__6_13_test1 = newaxialthermalcontraction(1:end,1);
       dPhi1_6_13_test1 = newaxialthermalcontraction(1:end,2); 
       
% Free Torsion PA 75 6-13-2019 Test 1
  filename = 'Free torsion 75PA Test 2 6-13-19';
    sheet = 'Sheet1';
     newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
       thetatemp_freeTorsion__6_13_test2 = newaxialthermalcontraction(1:end,1);
       dPhi1_6_13_test2 = newaxialthermalcontraction(1:end,2);       
       
fig5=figure; hold on; grid on; set(gca,'FontSize',20); %title('Pitch Angle 15 - Free Torsion, Change in Twist');
 

p1a = plot(thetatemp_freeTorsion__6_13_test1(1:477),dPhi1_6_13_test1(1:477),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
      plot(thetatemp_freeTorsion__6_13_test1(477:end),dPhi1_6_13_test1(477:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
p1b = plot(thetatemp_freeTorsion__6_13_test2(511:end),dPhi1_6_13_test2(511:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
      plot(thetatemp_freeTorsion__6_13_test2(1:511),dPhi1_6_13_test2(1:511),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
p2 = plot(temp-temp(1), twist,'rx','LineWidth',2)
p3 = plot(T-T(1),dPhi1,'k.','LineWidth',1)
p4 = plot(T-T(1),dPhi_avg,'k','LineWidth',1) 
p5 = plot(T-T(1),dPhi0_01,'k-.','LineWidth',1)
 xlim([0 80])
 ylim([-0.025 0.005])
 xlabel('Temperature Increment, $$\theta$$ ($$^{\circ}C$$)')
 ylabel('Shear Strain, $$\gamma_{z\theta}$$')
 legend([p1a p1b p2 p3 p4 p5],'Experimental Data - Heating'...
     ,'Experimental Data - Cooling',...
     'FEA','Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','FontSize',12,'Location','SouthWest')
%  %Set up how you want things sized on the output (cm?)
%     real_fig_width  = 6; %Desired with in latex-
%     real_fig_height = 4; %Desired with in latex-
%     scale_factor    = 3; %Scaled figure up by this so it appears the large on screen in matlab
%     real_fig_font_size = 8;
%     real_fig_legend_font_size = 4;
% 
% %Don't touch this stuff.
%     scaled_width = scale_factor*real_fig_width;
%     scaled_height = scale_factor*real_fig_height;
%     scaled_font_size = real_fig_font_size * scale_factor;
%     scaled_legend_font_size = real_fig_legend_font_size * scale_factor;
% savestring = ['strain_15'];
% set(findall(gcf,'-property','FontSize'),'FontSize',scaled_font_size)%Change all the other font sizes
% set(findobj(gcf, 'Type', 'Legend'),'FontSize',scaled_legend_font_size)%Change the legend font sizes
% PUBFIGPREP(fig5,'width',scaled_width,'height',scaled_height,'margin','on')
% results_location = 'Result_figures';
% print([savestring],'-dpdf','-fillpage')


fig6=figure; hold on; grid on; set(gca,'FontSize',20); %title('Pitch Angle 15 - Free Torsion, Axial Strain');
p1a = plot(thetatemp4(1:486),Epsilon_new4(1:486),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
      plot(thetatemp4(486:end),Epsilon_new4(486:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
 
p1b = plot(thetatemp5(668:end),Epsilon_new5(668:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
      plot(thetatemp5(1:668),Epsilon_new5(1:668),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
 
p2 = plot(temp-temp(1), axial,'rx','LineWidth',2)
p3 = plot(T-T(1),dL1,'k.','LineWidth',1)
p5 = plot(T-T(1),dL_avg,'k','LineWidth',1)
p6 = plot(T-T(1),dL0_01,'k-.','LineWidth',1)
% p7 = plot(thetatemp,Epsilon_new,'r','LineWidth',1)
 
xlim([0 80])
 ylim([-0.4 0.3])
% legend([p1a p1b p2 p5 p6 p3],'Trial 1 6-11-2019 (VIBROMETER) 50 microms/V Slow Track Filter','Trial 2 6-11-2019 (VIBROMETER) 50 microms/V Slow Track Filter',...
%    'FEA','Shafer Model: r = 0.01R','Shafer Model: Avg','Shafer Model: r = R')

%  legend([p1a p1b p2 p3 p5 p4],'Experimental Data - Heating'...
%      ,'Experimental Data - Cooling',...
%      'FEA','Shafer Model: r = 0.01R','Shafer Model: Avg','Shafer Model: r = R')
     

 xlabel('Temperature Increment, $$\theta$$ ($$^{\circ}C$$)')
 ylabel('Axial Strain, $$\varepsilon_{z}$$  ($$\%$$)')  
  legend([p1a p1b p2 p3 p5 p6],'Experimental Data - Heating'...
     ,'Experimental Data - Cooling',...
     'FEA','Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','FontSize',12,'Location','NorthEast')


% savestring = ['untwist_15'];
% set(findall(gcf,'-property','FontSize'),'FontSize',scaled_font_size)%Change all the other font sizes
% set(findobj(gcf, 'Type', 'Legend'),'FontSize',scaled_legend_font_size)%Change the legend font sizes
% PUBFIGPREP(fig6,'width',scaled_width,'height',scaled_height,'margin','on')
% results_location = 'Result_figures';
% print([savestring],'-dpdf','-fillpage')