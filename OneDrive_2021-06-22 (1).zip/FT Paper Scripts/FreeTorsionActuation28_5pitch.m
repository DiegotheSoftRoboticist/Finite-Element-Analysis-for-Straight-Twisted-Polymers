clear all
clc
close all


       

%        
% % Retrieve Charlie Data 
temp = [25:5:100];
%STRAIN = csvread('FT_285PA_5mm_mid_STRAIN.csv');
STRAIN = csvread('FT_285PA_5mm_e11update_STRAIN.csv');
twist = STRAIN(:,1);
axial = STRAIN(:,2)*100;

%Conversion to degrees and torque to N/mm
L0 = 17.5; %mm
D = 0.89; %mm
R = D/2; %mm


% Thermal strains:

% T = (23:1:95);
% T0 = 23;
% 
% TE22 = 10^(-6)*(1.1*(T.^2 - T0.^2) + 48.2*(T - T0)); % new newest
% %TE11 = 10^(-6)*(-0.0091*T.^3 + 0.9536*T.^2 - 32.05*T - (-0.0091*T0.^3 + 0.9536*T0.^2 - 32.05*T0)); % Newest
% TE11 = -2.811993987928945e-08*(T.^3-T0.^3) + 3.345051826452319e-06*(T.^2-T0.^2) -1.337544800607228e-04*(T-T0) % Least Squares Regretion Method
% %TE11 = 10^(-6)*(-0.006497*(T.^3 - T0.^3) - 0.241*(T.^2 -T0.^2) - 53.5*(T - T0)); % October 2018
% %TE11 = -9.951e-09*(T.^3 - T0.^3)+2.113e-07*(T.^2 -T0.^2)+ 3.159e-05*(T - T0); % May 2019
% 
% 
% Phi0 = 2*L0/(D*tan((28.5)));
% 
% r1 = 1*R; %Radial position
% r0_5 = 0.5*R;
% r0_01 = 0.01*R;
% 
% x1 = r1*Phi0/L0;
% x0_5 = r0_5*Phi0/L0;
% x0_01 = r0_01*Phi0/L0;
% 
% dPhi1 = 2*Phi0*(TE11 - TE22)/(x1^2+1)*R/L0; % delta phi, SMASIS
% % dPhi0_5 = 2*Phi0*(TE11 - TE22)/(x0_5^2+1)*R/L0; % delta phi, SMASIS
% dPhi0_01 = 2*Phi0*(TE11 - TE22)/(x0_01^2+1)*R/L0; % delta phi, SMASIS
% dL1 = L0*(TE22*x1^2 + TE11)/(x1^2+1)/L0*100; % delta L, SMASIS
% dL0_01 = L0*(TE22*x0_01^2 + TE11)/(x0_01^2+1)/L0*100; % delta L, SMASIS
% 
% 
% dL_avg = L0^3/(Phi0^2*R^2)*((TE11-TE22)*log(1+(Phi0*R/L0)^2) + TE22*(Phi0*R/L0)^2)/L0*100;
% dPhi_avg = 2*L0^2/(Phi0*R^2)*(TE11-TE22)*log((Phi0*R/L0)^2 + 1)*R/L0;
T = (23:1:110);
T0 = 23;

TE22 = 10^(-6)*(1.1*(T.^2 - T0.^2) + 48.2*(T - T0)); % new newest
%TE11 = 10^(-6)*(-0.0091*T.^3 + 0.9536*T.^2 - 32.05*T - (-0.0091*T0.^3 + 0.9536*T0.^2 - 32.05*T0)); % Newest
TE11 = (-1.905939104908804e-08*(T.^3-T0.^3) + 2.330006828099087e-06*(T.^2-T0.^2) -9.278398709519304e-05*(T-T0));
%TE11 = -2.811993987928945e-08*(T.^3-T0.^3) + 3.345051826452319e-06*(T.^2-T0.^2) -1.337544800607228e-04*(T-T0); % Least Squares Regression Method
%TE11 = 10^(-6)*(-0.006497*(T.^3 - T0.^3) - 0.241*(T.^2 -T0.^2) - 53.5*(T - T0)); % October 2018
%TE11 = -9.951e-09*(T.^3 - T0.^3)+2.113e-07*(T.^2 -T0.^2)+ 3.159e-05*(T - T0); % May 2019
%TE11_Amy = 10^(-6)*(-0.009357*(T.^3 - T0.^3) + 0.1005*(T.^2 -T0.^2) - 38.17*(T - T0)); % May 2019 AMY
%TE11_AmyCheck = 10^(-6)*(-0.009357*(T.^3 - T0.^3) + 0.1005*(T.^2 -T0.^2) + 38.17*(T - T0)); 

Phi0 = 2*L0/(D*tand(61.5));

r1 = 1*R; %Radial position
r0_5 = 0.5*R;
r0_01 = 0.01*R;

x1 = r1*Phi0/L0;
x0_5 = r0_5*Phi0/L0;
x0_01 = r0_01*Phi0/L0;

dPhi1 = 2*x1*(TE11 - TE22)/(x1^2+1); % delta phi, SMASIS
dPhi0_01 = 2*x0_01*(TE11 - TE22)/(x0_01^2+1); % delta phi, SMASIS
dL1 = L0*(TE22*x1^2 + TE11)/(x1^2+1)/L0*100; % delta L, SMASIS
dL0_01 = L0*(TE22*x0_01^2 + TE11)/(x0_01^2+1)/L0*100; % delta L, SMASIS. This term is equal to
%the axial thermal contraction when the pitch angle is equal to 0 degrees.


%dPhi_avg = 2*L0^2/(Phi0*R^2)*(TE11-TE22)*log((Phi0*R/L0)^2 + 1)*R/L0;
dL_avg = L0^3/(Phi0^2*R^2)*((TE11-TE22)*log(1+(Phi0*R/L0)^2) + TE22*(Phi0*R/L0)^2)/L0*100;
dPhi_avg = (4*L0*(TE11-TE22)/(R^2*Phi0^2))*(Phi0*R - (L0*atan(Phi0*R/L0)));

set(groot, 'DefaultTextInterpreter', 'LaTeX', ...
           'DefaultAxesTickLabelInterpreter', 'LaTeX', ...
           'DefaultAxesFontName', 'LaTeX', ...
           'DefaultLegendInterpreter', 'LaTeX', ...
           'defaultFigureColor','w');

fig1=figure; hold on; grid on; set(gca,'FontSize',20);

%Retrieve DATA Free torsion

%  % Retrieve Free torsion PA 26 6-30-2019 Test 1
  filename = 'Free torsion 26PA Test 1 6-30-19';
    sheet = 'Sheet1';
     FreeTorsion_6_30 = xlsread(filename, sheet,'A:B');
       thetatemp_freeTorsion__6_30_test1 = FreeTorsion_6_30(1:end,1);
       dPhi1_6_30_test1 = FreeTorsion_6_30(1:end,2);


%  % Retrieve Free torsion PA 26 6-30-2019 Test 2
  filename = 'Free torsion 26PA Test 2 6-30-19';
    sheet = 'Sheet1';
     FreeTorsion_6_30 = xlsread(filename, sheet,'A:B');
       thetatemp_freeTorsion__6_30_test2 = FreeTorsion_6_30(1:end,1);
       dPhi1_6_30_test2 = FreeTorsion_6_30(1:end,2);



fig5=figure; hold on; grid on; set(gca,'FontSize',20); %title('Pitch Angle 28.5 - Free Torsion, Change in Twist');
 
p1a = plot(thetatemp_freeTorsion__6_30_test1(1:360),dPhi1_6_30_test1(1:360),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
      plot(thetatemp_freeTorsion__6_30_test1(360:end),dPhi1_6_30_test1(360:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
p1b = plot(thetatemp_freeTorsion__6_30_test2(407:end),-dPhi1_6_30_test2(407:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
      plot(thetatemp_freeTorsion__6_30_test2(1:407),-dPhi1_6_30_test2(1:407),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
p2 = plot(temp-temp(1), twist,'rx','LineWidth',2)
p3 = plot(T-T(1),dPhi1,'.k','LineWidth',1)
p4 = plot(T-T(1),dPhi0_01,'-.k','LineWidth',1)
p5 = plot(T-T(1),dPhi_avg,'k','LineWidth',1) 
 xlim([0 80])
ylim([-0.025 0.005])
 xlabel('Temperature Increment, $$\theta$$ ($$^{\circ}C$$)')
 ylabel('Shear Strain, $$\gamma_{z\theta}$$')
%  legend([p1a p1b p2 p3 p4 p5],'Experimental Data - Heating'...
%      ,'Experimental Data - Cooling',...
%      'FEA','Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','Location','SouthWest') 
%  legend([p1a p1b p2 p3 p5 p4],'Experimental Data - Heating'...
%      ,'Experimental Data - Cooling',...
%      'FEA','Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','Location','SouthWest')


 % thermal axial contraction PA 25 6-23-2019 test 1
    filename = 'thermalaxialcontractiondata26PA Test 1 6-23-19';
    sheet = 'Sheet1';
     newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
       thetatemp6_23_19_1 = newaxialthermalcontraction(1:end,1);
       Epsilon_new6_23_19_1 = newaxialthermalcontraction(1:end,2);
       
 % thermal axial contraction PA 25 6-23-2019 test 1
    filename = 'thermalaxialcontractiondata26PA Test 2 6-23-19';
    sheet = 'Sheet1';
     newaxialthermalcontraction = xlsread(filename, sheet,'A:B');
       thetatemp6_23_19_2 = newaxialthermalcontraction(1:end,1);
       Epsilon_new6_23_19_2 = newaxialthermalcontraction(1:end,2);
       
       
fig6=figure; hold on; grid on; set(gca,'FontSize',20); %title('Pitch Angle 28.5 - Free Torsion, Axial Strain');

p1a = plot(thetatemp6_23_19_1(1:358),Epsilon_new6_23_19_1(1:358),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)
      plot(thetatemp6_23_19_1(358:end),Epsilon_new6_23_19_1(358:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
      
p1b = plot(thetatemp6_23_19_2(401:end),Epsilon_new6_23_19_2(401:end),':','Color',[0.3010 0.7450 0.9330],'LineWidth',2.5)
      plot(thetatemp6_23_19_2(1:401),Epsilon_new6_23_19_2(1:401),':','Color',[0.6350, 0.0780, 0.1840],'LineWidth',2.5)     
      
p2 = plot(temp-temp(1), axial,'rx','LineWidth',2)
p3 = plot(T-T(1),dL1,'.k','LineWidth',1)
p4 = plot(T-T(1),dL0_01,'-.k','LineWidth',1)
p5 = plot(T-T(1),dL_avg,'k','LineWidth',1) 


% 
% legend([p8 p9 p3 p5 p4],'Trial 1 6-23-2019 (VIBROMETER) 50 microms/V Slow Track Filter',...
%     'Trial 2 6-23-2019 (VIBROMETER) 50 microms/V Slow Track Filter',...
%    'Shafer Model: r = 0.01R','Shafer Model: Avg','Shafer Model: r = R')

 
xlim([0 80])
 ylim([-0.4 0.3])
 xlabel('Temperature Increment, $$\theta$$ ($$^{\circ}C$$)')
 ylabel('Axial Strain, $$\varepsilon_{z}$$  ($$\%$$)')  
%    legend([p1a p1b p2 p3 p4 p5],'Experimental Data - Heating'...
%      ,'Experimental Data - Cooling',...
%      'FEA','Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','Location','SouthWest')
%  title('STPA with a 54$$^{\circ}$$ Pitch Angle')
%   legend([p1a p1b p2 p3 p5 p4],'Experimental Data - Heating'...
%      ,'Experimental Data - Cooling',...
%      'FEA','Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','Location','NorthEast')




