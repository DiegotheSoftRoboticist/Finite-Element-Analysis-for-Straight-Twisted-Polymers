clear all 
close all
clc

%Stress and strain input format
% Column 1 = Element#, 2 = LE23, 3 = LE33, 4 = S11, 5 = S22, 6 = S33, 7 = S23

%DATA = csvread('FT_36PA_5mm_STRESS_STRAIN_RADIUS.csv');
DATA = csvread('FT_36PA_5mm_STRESS_STRAIN_RADIUS2.csv');
LE33 = DATA(:,2)*100;
LE23 = DATA(:,3);
S11 = DATA(:,4);
S22 = DATA(:,5);
S33 = DATA(:,6);
S23 = DATA(:,7);
THE33 = DATA(:,8)*100;
THE23 = DATA(:,9);

R = 0.445;
L0 = 2.5;
dr = 0.01;
for i = 1:length(DATA)
    if i == 1
        radius(i) = dr;

    else
        radius(i) = radius(i-1) + 0.02;

    end
end

x = [0,0.2,0.445];
y = [0,0,0];
set(groot, 'DefaultTextInterpreter', 'LaTeX', ...
           'DefaultAxesTickLabelInterpreter', 'LaTeX', ...
           'DefaultAxesFontName', 'LaTeX', ...
           'DefaultLegendInterpreter', 'LaTeX', ...
           'defaultFigureColor','w');

figure(1); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Radial Stress');
figure(2); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Axial Stress');
figure(3); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Z-$$\theta$$ Stress');
figure(4); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, $$\theta$$ Stress');
figure(5); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Axial Strain');
figure(6); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Z-$$\theta$$ Strain');

figure(1)
plot(radius,S11,'ko',x,y,'k--')
xlabel('Radius (mm)')
ylabel('Radial Stress, $$\sigma_{r}$$ (MPa)')
xlim([0 0.5])
figure(2)
plot(radius,S33,'ko',x,y,'k--')
xlabel('Radius (mm)')
ylabel('Axial Stress, $$\sigma_{z}$$ (MPa)')
xlim([0 0.5])
figure(3)
plot(radius,S23,'ko',x,y,'k--')
xlabel('Radius (mm)')
ylabel('Shear Stress, $$\tau_{z\theta}$$ (MPa)')
xlim([0 0.5])
figure(4)
plot(radius,S22,'ko',x,y,'k--')
xlabel('Radius (mm)')
ylabel('$$\theta$$ Stress, $$\sigma_{\theta}$$ (MPa)')
xlim([0 0.5])
figure(5)
plot(radius,LE33,'rx',radius,THE33,'xk','LineWidth',1.5)
xlabel('Radius (mm)')
ylabel('Axial Strain (%)')
xlim([0 0.5])
hold on
figure(6)
plot(radius,LE23,'rx',radius,THE23,'xk','LineWidth',1.5)
xlabel('Radius (mm)')
ylabel('Z-$$\theta$$ Strain (rad/rad)')
xlim([0 0.5])
hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate FT from Shafer Model
L0 = 2.5; %mm
D = 0.89; %mm
R = D/2; %mm
PA = 36;
T = 100;
T0 = 25;


%TE11 = -2.811993987928945e-08*(T.^3-T0.^3) + 3.345051826452319e-06*(T.^2-T0.^2) -1.337544800607228e-04*(T-T0); % Least Squares Regretion Method
TE11 = (-1.905939104908804e-08*(T.^3-T0.^3) + 2.330006828099087e-06*(T.^2-T0.^2) -9.278398709519304e-05*(T-T0)); %updated moisture method
TE22 = ((1.31)*(T.^2-T0^2)+9.29*(T-T0))*10^-6; % new newest
Phi0 = 2*L0/(D*tand(90-PA));
alpha_c = (90-PA)*(pi/180);

dL_avg100 = L0^3/(Phi0^2*R^2)*((TE11-TE22)*log(1+(Phi0*R/L0)^2) + TE22*(Phi0*R/L0)^2)/L0*100;
dPhi_avg100 = 2*L0^2/(Phi0*R^2)*(TE11-TE22)*log((Phi0*R/L0)^2 + 1)*R/L0;
P = 36;

for i = 1:length(radius)
%     alpha = (atan((R/radius(i))*tan(alpha_c)))*(180/pi);
%     check(i) = alpha;
%     Phi0 = L0/((radius(i))*tand(alpha));
%     x1 = radius(i)*Phi0/L0;
%     %dPhi(i) = 2*Phi0*(TE11 - TE22)/(x1^2+1)*(R/L0); % delta phi, SMASIS
%     dL(i) = L0*(TE22*x1^2 + TE11)/(x1^2+1)/L0*100; % delta L, SMASIS
%     dPhi(i) = 2*(TE11 - TE22)*(x1/(1+x1^2));
    PA0 = P*(pi/180);    
    PA = (atan((radius(i)/R)*tan(PA0)));
    check_rad(i) = PA;
    check_deg(i) = PA*(180/pi);
    Q = [cos(PA)^2, sin(PA)^2, -2*cos(PA)*sin(PA); 
    sin(PA)^2, cos(PA)^2, 2*cos(PA)*sin(PA); 
    cos(PA)*sin(PA), -cos(PA)*sin(PA), cos(PA)^2-sin(PA)^2];

    % Reuter's matrix for 1/2 factor of shear strain
    R2 = [1,0,0;0,1,0;0,0,2]; 

    %Thermal Strains
    %e11(i) = -2.811993987928945e-08*(T^3-T0^3) + 3.345051826452319e-06*(T^2-T0^2) -1.337544800607228e-04*(T-T0);
    e11(i) = (-1.905939104908804e-08*(T^3-T0^3) + 2.330006828099087e-06*(T^2-T0^2) -9.278398709519304e-05*(T-T0));
    e22(i)= ((1.31)*(T^2-T0^2)+9.29*(T-T0))*10^-6;

    e_prin = [e11(i); e22(i); 0]; 
    %Rotation of strains
    e_global = R2*Q*inv(R2)*e_prin;

    e_therm1(i) = e_global(1)*100; %Axial Thermal Strain
    e_therm12(i) = e_global(3);%Shear thermal strain (untwist)
    e_therm2(i) = e_global(2); %Theta Thermal Strain
    
    phi0 = L0/(R*tan(54*(pi/180)));
    x = (radius(i)*phi0)/L0;
    dL(i) = (e11(i)+(e22(i)*x^2))/(1+x^2)*100;
    dPhi(i) = 2*(e11(i)-e22(i))*(x/(1+x^2));
    
    dL_avg(i) = dL_avg100;
    %dPhi_avg(i) = dPhi_avg100*(radius(i)/R);
    dPhi_avg(i) = (4*L0*(e11(i)-e22(i))/(R^2*phi0^2))*(phi0*R - (L0*atan(phi0*R/L0)));
end


figure(5)
plot(radius,e_therm1,'-.k','LineWidth',1.5)
%plot(radius,dL_avg,'k-','LineWidth',1)
xlabel('Radius (mm)')
ylabel('Axial Strain, $$\varepsilon_{z}$$  ($$\%$$)') 
legend('FEA - Total Strain','FEA - Thermal Strain','Shafer Model Fnc. of r','Location','SouthEast')

figure(6)
plot(radius,e_therm12,'-.k','LineWidth',1.5)
%plot(radius,dPhi_avg,'k-','LineWidth',1)
xlabel('Radius (mm)')
ylabel('Shear Strain, $$\gamma_{z\theta}$$')
legend('FEA - Total Strain','FEA - Thermal Strain','Shafer Model Fnc. of r','Location','NorthEast')









