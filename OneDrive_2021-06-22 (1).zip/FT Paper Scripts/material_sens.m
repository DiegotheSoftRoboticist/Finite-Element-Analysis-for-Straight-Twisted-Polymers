clear all 
close all
clc

temp = [25:5:100];
STRAIN = csvread('FT_36PA_5mm_e11update_STRAIN.csv');
twist = STRAIN(:,1);
axial = STRAIN(:,2)*100;
STRAIN = csvread('FT_36PA_5mm_e11update_E1P_STRAIN.csv');
twistE1P = STRAIN(:,1);
axialE1P = STRAIN(:,2)*100;
STRAIN = csvread('FT_36PA_5mm_e11update_E1M_STRAIN.csv');
twistE1M = STRAIN(:,1);
axialE1M = STRAIN(:,2)*100;
STRAIN = csvread('FT_36PA_5mm_e11update_G12P_STRAIN.csv');
twistG12P = STRAIN(:,1);
axialG12P = STRAIN(:,2)*100;
STRAIN = csvread('FT_36PA_5mm_e11update_G12M_STRAIN.csv');
twistG12M = STRAIN(:,1);
axialG12M = STRAIN(:,2)*100;

set(groot, 'DefaultTextInterpreter', 'LaTeX', ...
           'DefaultAxesTickLabelInterpreter', 'LaTeX', ...
           'DefaultAxesFontName', 'LaTeX', ...
           'DefaultLegendInterpreter', 'LaTeX', ...
           'defaultFigureColor','w');

figure(1); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Radial Stress');
figure(2); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Axial Stress');
figure(3); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Z-$$\theta$$ Stress');
figure(6); hold on; grid on; set(gca,'FontSize',20); %title('Free Torsion, Z-$$\theta$$ Stress');

   
%%%%%%%%% START OF FREE TORSION %%%%%%%%%%%%%%%%%%
L0 = 17.5; %mm
D = 0.89; %mm
R = D/2; %mm


%ANALYTICAL FREE TORSION 

% Thermal strains:

T = (23:1:110);
T0 = 23;

TE22 = 10^(-6)*(1.1*(T.^2 - T0.^2) + 48.2*(T - T0)); % new newest
%TE11 = 10^(-6)*(-0.0091*T.^3 + 0.9536*T.^2 - 32.05*T - (-0.0091*T0.^3 + 0.9536*T0.^2 - 32.05*T0)); % Newest
%TE11 = -2.811993987928945e-08*(T.^3-T0.^3) + 3.345051826452319e-06*(T.^2-T0.^2) -1.337544800607228e-04*(T-T0) % Least Squares Regression Method
TE11 = (-1.905939104908804e-08*(T.^3-T0.^3) + 2.330006828099087e-06*(T.^2-T0.^2) -9.278398709519304e-05*(T-T0));
%TE11 = 10^(-6)*(-0.006497*(T.^3 - T0.^3) - 0.241*(T.^2 -T0.^2) - 53.5*(T - T0)); % October 2018
%TE11 = -9.951e-09*(T.^3 - T0.^3)+2.113e-07*(T.^2 -T0.^2)+ 3.159e-05*(T - T0); % May 2019
%TE11_Amy = 10^(-6)*(-0.009357*(T.^3 - T0.^3) + 0.1005*(T.^2 -T0.^2) - 38.17*(T - T0)); % May 2019 AMY
%TE11_AmyCheck = 10^(-6)*(-0.009357*(T.^3 - T0.^3) + 0.1005*(T.^2 -T0.^2) + 38.17*(T - T0)); 

Phi0 = 2*L0/(D*tand(54));

r1 = 1*R; %Radial position
r0_5 = 0.5*R;
r0_01 = 0.01*R;

x1 = r1*Phi0/L0;
x0_5 = r0_5*Phi0/L0;
x0_01 = r0_01*Phi0/L0;

dPhi1 = 2*x1*(TE11 - TE22)/(x1^2+1); % delta phi, SMASIS
dPhi0_01 = 2*x0_01*(TE11 - TE22)/(x0_01^2+1); % delta phi, SMASIS
dL1 = L0*(TE22*x1^2 + TE11)/(x1^2+1)/L0*100; % delta L, SMASIS
dL0_01 = L0*(TE22*x0_01^2 + TE11)/(x0_01^2+1)/L0*100; % delta L, SMASIS. This term is equal to
%the axial thermal contraction when the pitch angle is equal to 0 degrees.


%dPhi_avg = 2*L0^2/(Phi0*R^2)*(TE11-TE22)*log((Phi0*R/L0)^2 + 1)*R/L0;
dPhi_avg = (4*L0*(TE11-TE22)/(R^2*Phi0^2))*(Phi0*R - (L0*atan(Phi0*R/L0)));
dL_avg = L0^3/(Phi0^2*R^2)*((TE11-TE22)*log(1+(Phi0*R/L0)^2) + TE22*(Phi0*R/L0)^2)/L0*100;

% D = 0.00089; R = D/2; % m, TPA diameter and radius
%  
% % Comparison figure formatting and Model Prediction Plotting
%     r = [0.01*R, R]; lnspc = {'-.k','--k'}; % radial positions in the analytical model you want to plot
%   
%     figure(4);
%         %xlabel('Temperature ($$^{\circ}$$C)'); ylabel('Change in Twist, $$\Delta\Phi$$');
%     figure(5);
%         %xlabel('Temperature $$(^{\circ}C)$$'); ylabel('Strain, $$\varepsilon_{z}\hspace{1.5mm}(\%)$$');
% 
%     L0 = 13e-03; % Initial length from data
% 
%     Phi0 = 2*L0/(D*tan((90-36)*pi/180)); % non-dim, initial twist angle
%     
% 
%     T0 = 25; T = T0:0.1:110; % Initial temperature from data and temperature range
%     % Thermal Expansions in terms of the initial temperatures and temperature ranges
% 
%     TE22 = 10^(-6)*(1.1*(T.^2 -T0.^2) + 40.8*(T - T0)); % new newest
%     TE11 = -2.811993987928945e-08*(T.^3-T0.^3) + 3.345051826452319e-06*(T.^2-T0.^2) -1.337544800607228e-04*(T-T0); 
%     %TE11 = 10^(-6)*(-0.0091*T.^3 + 0.9536*T.^2 - 32.05*T - (-0.0091*T0.^3 + 0.9536*T0.^2 - 32.05*T0)); % Newest
% 
%     % Plot Shafer model predictions at specified radial positions
%     for i = 1:length(r)
%         ri = r(i);
%         x = ri*Phi0/L0;
%             
%             dPhi = 2*Phi0*(TE11 - TE22)/(x^2+1)*R/L0; % delta phi, SMASIS
%             figure(4);
%             plot(T-T(1), dPhi,lnspc{i});
%             hold on
%             
%            
%             dL = L0*(TE22*x^2 + TE11)/(x^2+1)/L0*100; % delta L, SMASIS
%             figure(5);
%             plot(T-T(1), dL,lnspc{i});
%             hold on
%         
%     end
%     % Averages of SMASIS Model
%   
%         dPhi_avg = 2*L0^2/(Phi0*R^2)*(TE11-TE22)*log((Phi0*R/L0)^2 + 1)*R/L0;
%         dPhi_avg_36 = dPhi_avg;
%         figure(4);
%         plot(T-T(1), dPhi_avg,'k');
%         hold on
%   
%    
%         dL_avg = L0^3/(Phi0^2*R^2)*((TE11-TE22)*log(1+(Phi0*R/L0)^2) + TE22*(Phi0*R/L0)^2)/L0*100;
%         dL_avg_36 = dL_avg;
%         figure(5);
%         plot(T-T(1), dL_avg,'k');
%         hold on    

% figure(4)
% plot(temp-temp(1),twist,'r-x','LineWidth',1.5)
% 
% figure(5)
% plot(temp-temp(1),axial,'r-x','LineWidth',1.5)

%Retrieve DATA Free torsion
% 
%  % Retrieve Free torsion PA 36 6-18-2019 Test 1
%   filename = 'Free torsion 36PA Test 1 6-17-19';
%     sheet = 'Sheet1';
%      FreeTorsion_6_17 = xlsread(filename, sheet,'A:B');
%        thetatemp_freeTorsion__6_17_test1 = FreeTorsion_6_17(1:end,1);
%        dPhi1_6_17_test1 = FreeTorsion_6_17(1:end,2);
% 
% 
% % Retrieve Free torsion PA 36 6-18-2019 Test 2
%   filename = 'Free torsion 36PA Test 2 6-17-19';
%     sheet = 'Sheet1';
%      FreeTorsion_6_17 = xlsread(filename, sheet,'A:B');
%        thetatemp_freeTorsion__6_17_test2 = FreeTorsion_6_17(1:end,1);
%        dPhi1_6_17_test2 = FreeTorsion_6_17(1:end,2);



 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig5=figure(4); hold on; grid on; set(gca,'FontSize',20);
plot(T-T(1),dPhi1,'k.','LineWidth',1)
plot(T-T(1),dPhi_avg,'k','LineWidth',1) 
plot(T-T(1),dPhi0_01,'k-.','LineWidth',1)
plot(temp-temp(1),twist,'r-x','LineWidth',1.5)
plot(temp-temp(1),twistG12P,'gx-','color',[0, 0.5, 0],'LineWidth',1.5)
hold on
plot(temp-temp(1),twistG12M,'mx-','LineWidth',1.5)

xlim([0 80])
ylim([-0.025 0.005])
xlabel('Temperature Increment, $$\theta (^{\circ}C)$$')
ylabel('Shear Strain, $$\gamma_{z\theta}$$')
legend('Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','FEA','FEA G12 +50$$\%$$'...
     ,'FEA G12 -50$$\%$$','Location','SouthWest')
 

fig6=figure(5); hold on; grid on; set(gca,'FontSize',20);
plot(T-T(1),dL1,'k.','LineWidth',1)
plot(T-T(1),dL_avg,'k','LineWidth',1)
plot(T-T(1),dL0_01,'k-.','LineWidth',1)
plot(temp-temp(1),axial,'r-x','LineWidth',1.5)
plot(temp-temp(1),axialE1P,'gx-','color',[0, 0.5, 0],'LineWidth',1.5) 
hold on 
plot(temp-temp(1),axialE1M,'mx-','LineWidth',1.5) 

xlim([0 80])
ylim([-0.4 0.3])
xlabel('Temperature Increment, $$\theta (^{\circ}C)$$')
ylabel('Axial Strain, $$\varepsilon_{z}$$  ($$\%$$)')
legend('Shafer Model: r = R','Shafer Model: Avg','Shafer Model: r = 0.01R','FEA','FEA E1 +50$$\%$$'...
     ,'EA E1 -50$$\%$$','Location','SouthWest')       

   
