%   This code takes the nodes and elements from a STPA model in abaqus and
%   outputs the element sets and sections for each radial position, to be
%   included in the "input deck" using *include, input=filename.inp
%
%   

clear
clc

%%%% INPUTS %%%%%
R=0.445; %Radius of FE model geometry (mm)
PA = 36; %Pitch angle of outside fibers measured from the vertical (degrees)
nodes = csvread('full_5mm_nodes.txt');
elements = csvread('full_5mm_elements.txt');

%%%% OUTPUTS %%%%
element_output = {'layer_sets.inp'}; %file name for element sets (must keep .inp)
section_output = {'material_orien.inp'}; %file name for material sections (must keep.inp)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

elements_edit = elements;
elements_radial = elements;

for i = 1:length(elements)
    for j = 1:8
        %Creating an array for all nodes that make up an element
        N(j) = elements(i,j+1); %Array of nodes that make up "i"th element
    end
    %Calculate the centroid of the given element
    C = centroid(N,nodes); 
    elements_edit(i,10) = C(1);  %average of X coordinates
    elements_edit(i,11) = C(2);  %average of Y coordinates
    elements_edit(i,12) = C(3);  %average of Z coordinates
    
    CR = ((C(1))^2 + (C(2))^2)^(1/2); %vector magnituude calculation for radial position
    
    elements_radial(i,10) = round(CR,3); %rounding the radial position to 3 decimal points
    elements_radial(i,11) = C(3); %Saving the axial position
end

%Sorting elements by their radial position, from center (0) to R (0.445).
%ERO = elements - radial - orginized
ERO = sortrows(elements_radial,[10 10]);

%Create a matrix [S] with each column containing the element # for a unique
%radial position. For example, comumn 1 would contrain all the elements at
%r = 0.1 mm and the last column would contain all elements at r = 0.445mm.
S = sections(ERO);

%Create the element sets for elements at the same radial position
abq_elset(S,element_output)
%Create the sections and local material rotation for each element set
mat_orien(ERO,R,PA,section_output)
