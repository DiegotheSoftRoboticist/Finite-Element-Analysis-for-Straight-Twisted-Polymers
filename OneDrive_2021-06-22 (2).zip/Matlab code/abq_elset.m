function abq_elset(S,element_output)
% This function takes the sections matrix and writes the element sets for
% each column, or each unique radial position. S is the matrix and
% element__output is the file name for the elements.

[r,c] = size(S);
k = 0;
fileID = fopen(element_output,'w'); %Create file for element sets
for i = 1:c
    k = k+1;
    str = "*elset, elset=Layer_0"+i; %Each layer is a unique radial position
    inp = str;
    fprintf(fileID, '%s\n',inp);
    
    for j = 1:r
        k = k+1;
        if S(j,i) > 0
            inp = S(j,i); %writing all the elements for a given column
            fprintf(fileID, '%d\n',inp);
        else
            k = k-1;
        end
    end
      
end
fclose(fileID);

