function [C] = centroid(N,nodes)
% This function takes the master node set (nodes) and the nodes that make
% up an element (N) and calculates the centroid coordinates X,Y,Z

N = sort(N); %Ensuring nodes a in ascending order
c=0;
for i = 1:length(N)
    c = c+1;
    X(1,c) = nodes(N(i),2); %Grab the X coordinate of node from master list
    Y(1,c) = nodes(N(i),3); %Grab the Y coordinate of node from master list
    Z(1,c) = nodes(N(i),4); %Grab the Z coordinate of node from master list

end

X_sum = 0;
Y_sum = 0;
Z_sum = 0;

for j=1:8
    X_sum = X_sum + X(1,j); %summing X coordinates
    Y_sum = Y_sum + Y(1,j); %summing Y coordinates
    Z_sum = Z_sum + Z(1,j); %summing Z coordinates
end

%Calculating the centroid with X, Y, and Z coordinates
C = [(X_sum/length(X)), (Y_sum/length(Y)), (Z_sum/length(Z))];