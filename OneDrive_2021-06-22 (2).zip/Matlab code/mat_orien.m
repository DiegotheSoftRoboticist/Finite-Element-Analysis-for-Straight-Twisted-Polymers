function mat_orien(ERO,R,PA,section_output)
%   This function creates and rotates local coordinate systems for each group
%   of radial positions. R is the radius of the geometry, PA is the pitch
%   angle at the outer layer, and section_output is the file name to be
%   saved.

fileID = fopen(section_output,'w'); %open file to write
alpha_t = PA*(pi/180); %pitch angle in radians
r = 0;
c = 0;
for i = 1:length(ERO)
    if i == 1
        c = c+1;
        r = r+1;
        %Calculate the pitch angle at a given radial position
        theta_t(1,c) = (atan(((ERO(i,10))/R)*tan(alpha_t)))*(180/pi);
        %Naming scheme for defining the orientation of coordinate system
        str = "*Orientation, name=Ori-"+c+", system=CYLINDRICAL";
        fprintf(fileID, '%s\n', str);
        %Coordinates for coordinate system with axial axis aligned with Z
        str = "0.,0.,0.,0.,0.,1.";
        fprintf(fileID, '%s\n', str);
        %Rotating the coordinate system about the r (1) axis by calculated PA
        str = "1, -"+theta_t(1,c);
        fprintf(fileID, '%s\n', str);
        %Creating the solid section to assign elements to this orientation
        str = "*Solid Section, elset=Layer_0"+c+", orientation=Ori-"+c+", material=Material-1";
        fprintf(fileID, '%s\n', str);
    
    elseif ERO(i,10) == ERO((i-1),10)
        r = r+1;
       
    else
        r = 1;
        c = c+1;
        %Calculate the pitch angle at a given radial position
        theta_t(1,c) = (atan(((ERO(i,10))/R)*tan(alpha_t)))*(180/pi);
        %Naming scheme for defining the orientation of coordinate system
        str = "*Orientation, name=Ori-"+c+", system=CYLINDRICAL";
        fprintf(fileID, '%s\n', str);
        %Coordinates for coordinate system with axial axis aligned with Z
        str = "0.,0.,0.,0.,0.,1.";
        fprintf(fileID, '%s\n', str);
        %Rotating the coordinate system about the r (1) axis by calculated PA
        str = "1, -"+theta_t(1,c);
        fprintf(fileID, '%s\n', str);
        %Creating the solid section to assign elements to this orientation
        str = "*Solid Section, elset=Layer_0"+c+", orientation=Ori-"+c+", material=Material-1";
        fprintf(fileID, '%s\n', str);
    end       
end
fclose(fileID);