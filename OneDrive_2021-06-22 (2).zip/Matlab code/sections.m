function [S] = sections(ERO)
%   This function takes the elements that are sorted by radial position and
%   creates a new matrix where each column is the list of elements at a given
%   radial position. For example, comumn 1 would list all the elements at
%   r = 0.1 mm and the last column would list all elements at r = 0.445mm.
%
% ERO is a matrix with column 1 being a list of all elements in ascending
% order. Columns 2-9 are the nodes that make the element listed in column
% 1. Column 10 is the radial position of the given element in column 1.

r = 0; %row counter
c = 0; %column counter
for i = 1:length(ERO) 
    if i == 1
        c = c+1; %start column
        r = r+1; %start row
        S(r,c) = ERO(i,1);
        S(r) = ERO(i,1);
    elseif ERO(i,10) == ERO((i-1),10) %check for a new radial position
        r = r+1; %new row
        S(r,c) = ERO(i,1);
    else
        r = 1; %back to row 1
        c = c+1; %new column
        S(r,c) = ERO(i,1);
    end      
end
